const Trips = require("../models/Trip");

const create = (tripData, userId) => {
  let trips = new Trips({
    ...tripData,
    creator: userId,
  });
  return trips.save();
};
const getAll = () =>
  Trips.find({})
    .lean()
    .then((trips) => {
      console.log(trips);
      return trips;
    });

module.exports = {
  create,
  getAll,
  //   getOne,
  //   deleteTrip,
};
