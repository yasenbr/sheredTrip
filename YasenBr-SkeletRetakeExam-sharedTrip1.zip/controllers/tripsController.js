const router = require("express").Router();
const tripServices = require("../services/tripServices");

router.get("/displayTrip", (req, res, next) => {
  if (req.user) {
    tripServices
      .getAll(req.user._id)
      .then((trips) => {
        res.render("sharedTrip", { trips });
      })
      .catch(next);
  } else {
    res.render("sharedTrip");
  }
});

router.get("/displayTrip/create", (req, res) => {
  res.render("offerTrip");
});

router.post("/displayTrip/create", (req, res, next) => {
  let tripData = extractTripData(req);
  tripServices
    .create(tripData, req.user._id)
    .then((createdTrip) => {
      res.redirect("/");
    })
    .catch(next);
});

function extractTripData(req) {
  let { trip, date, seat, description, carImg } = req.body;

  let tripData = {
    trip,
    date,
    seat,
    description,
    carImg,
  };

  return tripData;
}

module.exports = router;
